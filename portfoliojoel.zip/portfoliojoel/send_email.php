<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération et sécurisation des données
    $name = htmlspecialchars($_POST['name'] ?? '');
    $email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $subject = htmlspecialchars($_POST['subject'] ?? '');
    $message = htmlspecialchars($_POST['message'] ?? '');
    $phone = htmlspecialchars($_POST['phone'] ?? '');

    // Validation
    $errors = [];
    if (empty($name)) $errors[] = "Le nom est requis";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Email invalide";
    if (empty($subject)) $errors[] = "Le sujet est requis";
    if (empty($message)) $errors[] = "Le message est requis";

    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'errors' => $errors]);
        exit;
    }

    $mail = new PHPMailer(true);

    try {
        // Configuration SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'toyatankwajoelsorel@gmail.com'; // Votre email Gmail
        $mail->Password = 'kkeo hkfq uwvr bzsn'; // Mot de passe d'application
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        $mail->CharSet = 'UTF-8';

        // Destinataires
        $mail->setFrom('toyatankwajoelsorel@gmail.com', 'Portfolio - ' . $name);
        $mail->addAddress('lazanosorel@gmail.com'); // Email de réception
        if (!empty($email)) {
            $mail->addReplyTo($email, $name);
        }

        // Contenu
        $mail->isHTML(true);
        $mail->Subject = "Nouveau message portfolio: " . $subject;
        
        $mail->Body = "
            <h2>Nouveau message depuis votre portfolio</h2>
            <p><strong>Nom:</strong> {$name}</p>
            <p><strong>Email:</strong> {$email}</p>
            " . (!empty($phone) ? "<p><strong>Téléphone:</strong> {$phone}</p>" : "") . "
            <p><strong>Sujet:</strong> {$subject}</p>
            <h3>Message:</h3>
            <p>" . nl2br($message) . "</p>
            <hr>
            <p>Envoyé le " . date('d/m/Y H:i') . "</p>
        ";

        // Version texte pour les clients mail simples
        $mail->AltBody = "Nouveau message portfolio\n\n"
            . "Nom: {$name}\n"
            . "Email: {$email}\n"
            . (!empty($phone) ? "Téléphone: {$phone}\n" : "")
            . "Sujet: {$subject}\n\n"
            . "Message:\n{$message}\n\n"
            . "Envoyé le " . date('d/m/Y H:i');

        $mail->send();
        echo json_encode(['success' => true, 'message' => 'Message envoyé avec succès!']);
    } catch (Exception $e) {
        error_log('Erreur PHPMailer: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'success' => false, 
            'message' => "Erreur lors de l'envoi du message",
            'error' => $mail->ErrorInfo
        ]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
}
?>